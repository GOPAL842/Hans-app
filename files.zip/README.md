```markdown
# Army Capture Game - Node.js Prototype

यह एक साधारण टर्न-आधारित सिम्युलेशन है जहाँ दो सेनाएँ ग्रिड पर भूमि के लिए लड़ती हैं। उद्देश्य: 100 लेवल के स्केल के अनुसार दिक्कत बढ़ाते हुए भूमि पर नियंत्रण हासिल करना।

## कैसे चलाएँ
1. सुनिश्चित करें कि Node.js (v14+) आपके सिस्टम पर installed है।
2. फाइलें `game.js` और `index.js` एक ही फोल्डर में रखें।
3. टर्मिनल में:
   node index.js 1
   (यह Level 1 रन करेगा। Level 1..100 पास कर सकते हैं)

## प्रमुख मैकेनिक्स
- टाइल्स (Tile) हर टर्न पर कैप्चर प्रोग्रेस से बदली जा सकती हैं।
- यूनिट्स हमला कर सकती हैं, मूव कर सकती हैं और टाइल्स को कैप्चर कर सकती हैं।
- विजयी शर्तें:
  - किसी सेना का कुल टाइल्स > 50% (majority)
  - विरोधी का बेस टाइल कब्ज़ा में आना
  - विरोधी की यूनिट्स न होना

## आगे के सुधार (suggestions)
- बेहतर pathfinding (A* या flow-field)
- UI (canvas / web)
- authoritative multiplayer server + deterministic replay recording
- unit abilities, supply lines, fog of war
- performance: batch combat resolution, worker threads
